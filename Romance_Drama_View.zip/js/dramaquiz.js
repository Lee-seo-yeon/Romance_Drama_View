function Title1(){
    document.date.src = "image/cookie1.png";
    date = prompt("드라마 제목 중 ㅅㅅㅎ ㅍㅌㄴ (은)는 무엇일까요?")
    if(date == "수상한 파트너"){
      alert("정답!!"); 
    }
    else{
      alert("땡!! 정답은 '수상한 파트너' 입니다");
    }
  }
  
  function Title2(){
    document.jack.src = "image/cookie2.png";
    name = prompt(" tvN에서 방영한 정소민, 이민기 주연의 '홈리스'와 '하우스푸어'가 주제인 드라마 제목은 무엇일까요?", "띄어쓰기 없이 작성하세요")
    if(name == "이번생은처음이라"){
      alert("정답!!"); 
    }
    else{
      alert("땡 !! 정답은 '이번생은처음이라' 입니다");
    }
  }

  function Title3(){
    document.bat.src = "image/cookie3.png";
    a = prompt("드라마 '날 녹여주오'에서 냉동인간은 몇년동안 냉동되어 있었을까요?")
    if(a == "20년"){
      alert("정답!!");
    }
    else{
      alert("땡 !! 정답은 '20년' 입니다");
    }
  }

  function Title4(){
    document.cauldron.src = "image/cookie4.png";
    speech = prompt("드라마 '달의연인'에서 주인공이 과거로 돌아간 시대의 이름은 무엇일까요?", "(예 : 조선시대)")
    if(speech == "고려시대"){
      alert("정답!!");
    }
    else{
      alert("땡!! 정답은 '고려시대' 입니다");
    }
  }

  function Title5(){
    document.hh.src = "image/cookie5.png";
    name = prompt("드라마 'W'의 주인공 이종석의 극중이름은 무엇일까요?")
    if(name == "강철"){
      alert("정답!!"); 
    }
    else{
      alert("땡 !! 정답은 '강철' 입니다");
    }
  }

  function Title6(){
    document.poison.src = "image/cookie6.png";
    dont = prompt("'치즈인더트랩', 'WATCHER', '제3의 매력'에 공통적으로 출연한 배우의 이름은 무엇일까요?")
    if(dont == "서강준"){
      alert("정답!!");
    }
    else{
      alert("땡 !! 정답은 '서강준' 입니다");
    }
  } 